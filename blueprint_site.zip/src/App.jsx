// App placeholder
export default function App(){ return (<h1>Blueprint Beginnings Site</h1>); }